#!/usr/bin/env python3
"""Bookmarks: server lifecycle helper (restore / restart / uninstall).

Spawned detached from the admin API (the same pattern as update.py):

    python serverctl.py restore --file <pending.sqlite3>
    python serverctl.py restart
    python serverctl.py uninstall

The helper is a child of the app process and the unit runs with
KillMode=process, so ``systemctl stop`` kills only the main PID and
this helper survives to finish the job (replace the database, restart
the service, remove the installation). Progress is written to
``<data>/ctl-status.json`` so the admin panel can report the result.

Only the stdlib is used, exactly like update.py.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SERVICE = "bookmarks"
UNIT_FILE = Path("/etc/systemd/system/bookmarks.service")
DEFAULT_PORT = 8765


def data_dir() -> Path:
    return Path(os.environ.get("BOOKMARKS_DATA") or (ROOT / "data"))


def port() -> int:
    try:
        info = json.loads((ROOT / "install.json").read_text(encoding="utf-8"))
        return int(info.get("port") or DEFAULT_PORT)
    except (OSError, ValueError):
        return DEFAULT_PORT


def have_systemd() -> bool:
    return shutil.which("systemctl") is not None and UNIT_FILE.exists()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def status(cmd: str, state: str, **extra) -> None:
    """Best-effort progress write that the admin API reads back."""
    try:
        directory = data_dir()
        directory.mkdir(parents=True, exist_ok=True)
        payload = {"cmd": cmd, "state": state, "at": now_iso(), **extra}
        tmp = directory / f".ctl-status.{os.getpid()}.json"
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, directory / "ctl-status.json")
    except OSError:
        pass  # e.g. uninstall: the data dir is being removed


def run(cmd: list[str], timeout: int = 120) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def wait_health(timeout: int = 45) -> bool:
    """Poll /health until the server answers ok (or the timeout expires)."""
    url = f"http://127.0.0.1:{port()}/health"
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as response:
                payload = json.loads(response.read().decode("utf-8", "replace"))
            if response.status == 200 and payload.get("ok"):
                return True
        except Exception:  # noqa: BLE001 - the server is probably still down
            pass
        time.sleep(1.5)
    return False


def verify_backup(path: Path) -> str | None:
    """Return an error code if the file is not a usable Bookmarks database."""
    try:
        with open(path, "rb") as handle:
            header = handle.read(16)
    except OSError as exc:
        return f"read_failed: {exc}"
    if header[:16] != b"SQLite format 3\x00":
        return "not_sqlite"
    try:
        check = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            row = check.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'users'"
            ).fetchone()
        finally:
            check.close()
    except sqlite3.Error as exc:
        return f"unreadable: {exc}"
    if row is None:
        return "no_users_table"
    return None


def do_restore(pending: str) -> int:
    if not have_systemd():
        status("restore", "error", message="no-systemd")
        return 1
    path = Path(pending)
    problem = verify_backup(path)
    if problem:
        status("restore", "error", message=problem)
        return 1
    status("restore", "running", message="stopping", pid=os.getpid())
    run(["systemctl", "stop", SERVICE])
    time.sleep(2)  # let the main PID release the database
    db_file = data_dir() / "bookmarks.db"
    os.replace(path, db_file)
    for base in (db_file, path):  # the pending file's sidecars are orphans now
        for suffix in ("-wal", "-shm"):
            try:
                (base.parent / (base.name + suffix)).unlink()
            except OSError:
                pass
    status("restore", "running", message="starting", pid=os.getpid())
    run(["systemctl", "start", SERVICE])
    if wait_health():
        status("restore", "success", pid=os.getpid())
        return 0
    status("restore", "error", message="health_failed", pid=os.getpid())
    return 1


def do_restart() -> int:
    if not have_systemd():
        status("restart", "error", message="no-systemd")
        return 1
    status("restart", "running", pid=os.getpid())
    run(["systemctl", "restart", SERVICE])
    if wait_health():
        status("restart", "success", pid=os.getpid())
        return 0
    status("restart", "error", message="health_failed", pid=os.getpid())
    return 1


def do_uninstall() -> int:
    if not have_systemd():
        status("uninstall", "error", message="no-systemd")
        return 1
    status("uninstall", "running", message="removing", pid=os.getpid())
    run(["systemctl", "stop", SERVICE])
    run(["systemctl", "disable", SERVICE])
    try:
        UNIT_FILE.unlink()
    except OSError:
        pass
    run(["systemctl", "daemon-reload"])
    time.sleep(1)
    shutil.rmtree(ROOT, ignore_errors=True)
    status("uninstall", "success", pid=os.getpid())  # best effort: data/ may be gone
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Bookmarks server lifecycle helper.")
    sub = parser.add_subparsers(dest="command", required=True)
    restore = sub.add_parser("restore", help="replace the database from a backup")
    restore.add_argument("--file", required=True, help="pending backup file")
    sub.add_parser("restart", help="restart the systemd service")
    sub.add_parser("uninstall", help="stop, disable and remove the installation")
    args = parser.parse_args()
    if args.command == "restore":
        return do_restore(args.file)
    if args.command == "restart":
        return do_restart()
    return do_uninstall()


if __name__ == "__main__":
    sys.exit(main())
