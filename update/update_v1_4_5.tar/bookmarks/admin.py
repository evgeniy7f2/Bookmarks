"""Admin panel API: global statistics and the user directory.

All endpoints require an authenticated admin (users.is_admin = 1).
The first account of an installation is created as an admin; further
admins are granted from the panel itself or with ``manage.py make-admin``.
"""

from __future__ import annotations

import json
import os
import platform
import re
import secrets
import shutil
import sqlite3
import subprocess
import sys
import time
from datetime import timedelta
from functools import wraps
from pathlib import Path

from flask import (
    Blueprint,
    after_this_request,
    current_app,
    g,
    jsonify,
    request,
    send_file,
)

from .auth import registration_open, registration_override
from .db import SCHEMA_VERSION, get_db
from .util import (
    APP_VERSION,
    LIMIT_BOUNDS,
    MAX_BOOKMARKS_PER_USER,
    MAX_GROUPS_PER_USER,
    MAX_TAGS_PER_USER,
    hash_password,
    hash_token,
    iso,
    parse_iso,
    utcnow,
)

bp = Blueprint("admin", __name__, url_prefix="/api/admin")

# Process start, used for the uptime figure in the summary.
START_MONOTONIC = time.monotonic()


def admin_required(view):
    """Allow only logged-in admins; everyone else sees the usual codes."""

    @wraps(view)
    def wrapper(*args, **kwargs):
        user = g.get("user")
        if user is None:
            return jsonify({"error": "unauthorized"}), 401
        if not user["is_admin"]:
            return jsonify({"error": "not_admin"}), 403
        return view(*args, **kwargs)

    return wrapper


def _json() -> dict:
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def _user_row(db, user_id: int):
    return db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


def _user_payload(db, row) -> dict:
    uid = row["id"]
    bookmarks = db.execute(
        "SELECT COUNT(*) c FROM bookmarks WHERE user_id = ? AND deleted_at IS NULL", (uid,)
    ).fetchone()["c"]
    trash = db.execute(
        "SELECT COUNT(*) c FROM bookmarks WHERE user_id = ? AND deleted_at IS NOT NULL", (uid,)
    ).fetchone()["c"]
    groups = db.execute(
        "SELECT COUNT(*) c FROM groups WHERE user_id = ? AND kind = 'custom'", (uid,)
    ).fetchone()["c"]
    tags = db.execute("SELECT COUNT(*) c FROM tags WHERE user_id = ?", (uid,)).fetchone()["c"]
    sessions = db.execute(
        "SELECT COUNT(*) c FROM sessions WHERE user_id = ?", (uid,)
    ).fetchone()["c"]
    return {
        "id": uid,
        "username": row["username"],
        "display_name": row["display_name"],
        "avatar_color": row["avatar_color"],
        "avatar_photo": row["avatar_photo"],
        "is_admin": bool(row["is_admin"]),
        "disabled": bool(row["disabled"]),
        "created_at": row["created_at"],
        "last_login": row["last_login"],
        "bookmarks": bookmarks,
        "trash": trash,
        "groups": groups,
        "tags": tags,
        "sessions": sessions,
        "limits": {
            "bookmarks": int(row["max_bookmarks"] or MAX_BOOKMARKS_PER_USER),
            "tags": int(row["max_tags"] or MAX_TAGS_PER_USER),
            "groups": int(row["max_groups"] or MAX_GROUPS_PER_USER),
        },
        "custom_limits": {
            "bookmarks": row["max_bookmarks"],
            "tags": row["max_tags"],
            "groups": row["max_groups"],
        },
    }


@bp.get("/summary")
@admin_required
def summary():
    db = get_db()
    active_since = iso(utcnow() - timedelta(days=30))
    rows = db.execute(
        """
        SELECT
            (SELECT COUNT(*) FROM users) AS users_total,
            (SELECT COUNT(*) FROM users WHERE disabled = 1) AS users_disabled,
            (SELECT COUNT(*) FROM users WHERE last_login IS NOT NULL
                AND last_login >= ?) AS users_active_30d,
            (SELECT COUNT(*) FROM bookmarks WHERE deleted_at IS NULL) AS bookmarks,
            (SELECT COUNT(*) FROM bookmarks WHERE deleted_at IS NOT NULL) AS trash,
            (SELECT COUNT(*) FROM groups WHERE kind = 'custom') AS groups,
            (SELECT COUNT(*) FROM tags) AS tags
        """,
        (active_since,),
    ).fetchone()
    try:
        db_size = os.path.getsize(current_app.config["DATABASE"])
    except OSError:
        db_size = 0
    return jsonify(
        {
            **dict(rows),
            "db_size_bytes": db_size,
            "version": APP_VERSION,
            "schema": SCHEMA_VERSION,
            "uptime_seconds": int(time.monotonic() - START_MONOTONIC),
            "registration_open": registration_open(db),
            "registration_control_enabled": registration_override() is None,
        }
    )


@bp.patch("/settings")
@admin_required
def update_settings():
    data = _json()
    enabled = data.get("registration_open")
    if not isinstance(enabled, bool):
        return jsonify({"error": "invalid_payload"}), 400

    db = get_db()
    override = registration_override()
    if override is not None:
        if enabled != override:
            return jsonify({"error": "registration_env_override"}), 409
        return jsonify(
            {
                "registration_open": override,
                "registration_control_enabled": False,
            }
        )

    db.execute(
        "INSERT INTO app_meta(key, value) VALUES ('registration_open', ?)"
        " ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        ("1" if enabled else "0",),
    )
    db.commit()
    return jsonify(
        {
            "registration_open": enabled,
            "registration_control_enabled": True,
        }
    )


@bp.get("/users")
@admin_required
def list_users():
    db = get_db()
    rows = db.execute("SELECT * FROM users ORDER BY id").fetchall()
    return jsonify(
        {
            "users": [_user_payload(db, row) for row in rows],
            "defaults": {
                "bookmarks": MAX_BOOKMARKS_PER_USER,
                "tags": MAX_TAGS_PER_USER,
                "groups": MAX_GROUPS_PER_USER,
            },
        }
    )


def _parse_limit(raw, kind: str) -> int | None | tuple:
    """Normalise an admin-supplied quota override.

    Returns (value, None) on success — value may be None (back to the
    global default) — or (None, error) on failure.
    """
    if raw is None:
        return None, None
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None, "invalid_limit"
    low, high = LIMIT_BOUNDS[kind]
    if not low <= value <= high:
        return None, "invalid_limit"
    return value, None


@bp.patch("/users/<int:user_id>")
@admin_required
def update_user(user_id: int):
    data = _json()
    db = get_db()
    row = _user_row(db, user_id)
    if row is None:
        return jsonify({"error": "user_not_found"}), 404
    me = int(g.user["id"])
    admins_count = db.execute(
        "SELECT COUNT(*) c FROM users WHERE is_admin = 1"
    ).fetchone()["c"]

    updates: dict[str, object] = {}
    if "is_admin" in data:
        value = 1 if data["is_admin"] else 0
        if value == 0 and row["is_admin"] and admins_count == 1:
            # Demoting oneself is fine while another admin exists; the
            # last admin is refused so the panel never becomes unreachable.
            return jsonify({"error": "last_admin"}), 400
        updates["is_admin"] = value
    if "disabled" in data:
        value = 1 if data["disabled"] else 0
        if value == 1:
            # A blocked last admin makes the panel unreachable without a
            # CLI, so this is refused first (for the target as well).
            stays_admin = bool(data.get("is_admin", row["is_admin"]))
            if row["is_admin"] and stays_admin and admins_count == 1:
                return jsonify({"error": "last_admin"}), 400
            if user_id == me:
                # Locking oneself out requires another admin to unlock.
                return jsonify({"error": "cannot_change_self"}), 400
        updates["disabled"] = value

    for field in ("max_bookmarks", "max_tags", "max_groups"):
        if field not in data:
            continue
        kind = field.removeprefix("max_")
        value, problem = _parse_limit(data.get(field), kind)
        if problem:
            return jsonify({"error": problem}), 400
        updates[field] = value

    if not updates:
        return jsonify({"error": "nothing_to_update"}), 400
    assignments = ", ".join(f"{column} = ?" for column in updates)
    db.execute(
        f"UPDATE users SET {assignments} WHERE id = ?",
        (*updates.values(), user_id),
    )
    db.commit()
    row = _user_row(db, user_id)
    return jsonify({"user": _user_payload(db, row)})


@bp.post("/users/<int:user_id>/password")
@admin_required
def reset_password(user_id: int):
    data = _json()
    password = str(data.get("password") or "")
    if len(password) < 8:
        return jsonify({"error": "weak_password"}), 400
    if len(password) > 200:
        return jsonify({"error": "password_too_long"}), 400
    db = get_db()
    row = _user_row(db, user_id)
    if row is None:
        return jsonify({"error": "user_not_found"}), 404
    db.execute(
        "UPDATE users SET password_hash = ? WHERE id = ?",
        (hash_password(password), user_id),
    )
    if user_id == int(g.user["id"]):
        # Keep the caller's own session, like a regular password change.
        token = request.cookies.get(current_app.config["SESSION_COOKIE"])
        db.execute(
            "DELETE FROM sessions WHERE user_id = ? AND token_hash <> ?",
            (user_id, hash_token(token or "")),
        )
    else:
        db.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
    db.commit()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Backup / restore / server control
# ---------------------------------------------------------------------------
#
# restore / restart / uninstall are performed by serverctl.py, a detached
# child of this process (same pattern as update.py). The unit runs with
# KillMode=process, so the helper survives "systemctl stop" and can finish
# the job. Progress lands in <data>/ctl-status.json.

CTL_STATUS_NAME = "ctl-status.json"
PENDING_RESTORE_NAME = "restore-pending.sqlite3"
SERVICE_NAME = "bookmarks"
UNIT_PATH = "/etc/systemd/system/bookmarks.service"
CTL_STALE_AFTER = timedelta(minutes=5)


def _ctl_status_path() -> str:
    return os.path.join(current_app.config["DATA_DIR"], CTL_STATUS_NAME)


def _read_ctl_status() -> dict | None:
    try:
        with open(_ctl_status_path(), "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def _write_ctl_status(cmd: str, state: str, **extra) -> None:
    path = _ctl_status_path()
    payload = {"cmd": cmd, "state": state, "at": iso(), **extra}
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False)
    os.replace(tmp, path)


def _systemd_ok() -> bool:
    """These actions need the systemd unit created by install.sh."""
    return shutil.which("systemctl") is not None and os.path.exists(UNIT_PATH)


def _ctl_running() -> dict | None:
    info = _read_ctl_status()
    if not info or info.get("state") != "running":
        return None
    stamp = parse_iso(str(info.get("at") or ""))
    if stamp is not None and utcnow() - stamp > CTL_STALE_AFTER:
        return None  # the helper died without writing the final state
    return info


def _spawn_ctl(*args: str) -> subprocess.Popen:
    data_dir = current_app.config["DATA_DIR"]
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    log_file = open(os.path.join(data_dir, "ctl.log"), "ab")
    kwargs: dict = dict(cwd=root, stdout=log_file, stderr=subprocess.STDOUT)
    if os.name == "nt":
        kwargs["creationflags"] = 0x00000010 | 0x00000200  # detached process
    else:
        kwargs["start_new_session"] = True
    try:
        proc = subprocess.Popen([sys.executable, "serverctl.py", *args], **kwargs)
    except OSError:
        log_file.close()
        raise
    log_file.close()
    return proc


def _remove_sqlite_file(path: Path) -> None:
    """Delete a SQLite file and its -wal/-shm sidecars (best effort)."""
    for name in (str(path), f"{path}-wal", f"{path}-shm"):
        try:
            os.unlink(name)
        except OSError:
            pass


def _remove_sqlite_sidecars(path: Path) -> None:
    for suffix in ("-wal", "-shm"):
        try:
            os.unlink(f"{path}{suffix}")
        except OSError:
            pass


def _validate_backup_file(path: Path) -> str | None:
    """Error code if the file is not a readable Bookmarks database."""
    try:
        with open(path, "rb") as handle:
            header = handle.read(16)
    except OSError:
        return "no_file"
    if header[:16] != b"SQLite format 3\x00":
        return "not_sqlite"
    try:
        check = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            row = check.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'users'"
            ).fetchone()
        finally:
            check.close()
    except sqlite3.Error:
        return "unreadable"
    if row is None:
        return "no_users_table"
    return None


def _sanitize_backup_name(raw) -> str:
    name = str(raw or "").strip().replace("\\", "/").rsplit("/", 1)[-1].strip()
    name = re.sub(r"[^A-Za-z0-9._-]", "_", name)[:80]
    if not name:
        name = time.strftime("bookmarks-%Y%m%d-%H%M%S") + ".sqlite3"
    if not name.lower().endswith(".sqlite3"):
        name += ".sqlite3"
    return name


@bp.get("/backup")
@admin_required
def backup_db():
    """A consistent online copy of the whole database, as a download."""
    name = _sanitize_backup_name(request.args.get("name"))
    db_path = current_app.config["DATABASE"]
    tmp_path = os.path.join(
        current_app.config["DATA_DIR"], f".backup-{secrets.token_hex(6)}.sqlite3"
    )
    source = sqlite3.connect(db_path)
    try:
        destination = sqlite3.connect(tmp_path)
        try:
            source.backup(destination)
        finally:
            destination.close()
    finally:
        source.close()

    @after_this_request
    def _cleanup(response):  # noqa: F811 - per-request hook
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        return response

    return send_file(
        tmp_path,
        mimetype="application/octet-stream",
        as_attachment=True,
        download_name=name,
    )


@bp.post("/restore")
@admin_required
def restore_db():
    """Replace the database from an uploaded backup (the server restarts)."""
    if _ctl_running():
        return jsonify({"error": "already_running"}), 409
    upload = request.files.get("file")
    if upload is None or not upload.filename:
        return jsonify({"error": "no_file"}), 400
    data_dir = Path(current_app.config["DATA_DIR"])
    pending = data_dir / PENDING_RESTORE_NAME
    tmp = data_dir / f".{PENDING_RESTORE_NAME}.tmp"
    _remove_sqlite_file(tmp)  # leftovers from an interrupted previous upload
    upload.save(tmp)
    problem = _validate_backup_file(tmp)
    if problem:
        _remove_sqlite_file(tmp)
        return jsonify({"error": problem}), 400
    _remove_sqlite_sidecars(tmp)  # sidecars created by the validation open
    if not _systemd_ok():
        _remove_sqlite_file(tmp)
        return jsonify({"error": "no-systemd"}), 409
    _remove_sqlite_file(pending)  # leftovers from an interrupted restore
    os.replace(tmp, pending)  # os.replace also clears a stale pending file
    try:
        proc = _spawn_ctl("restore", "--file", str(pending))
    except OSError as exc:
        _write_ctl_status("restore", "error", message="start_failed")
        return jsonify({"error": "start_failed", "detail": str(exc)}), 500
    _write_ctl_status("restore", "running", pid=proc.pid)
    return jsonify({"started": True, "pid": proc.pid})


@bp.get("/restore-status")
def restore_status():
    """One-shot restore result. Public on purpose: right after a restore
    the session cookie may belong to the old database and be unknown."""
    info = _read_ctl_status()
    if not info or info.get("cmd") != "restore":
        return jsonify({"state": "none"})
    if info.get("state") in ("success", "error"):
        try:  # consume so later polls (or a page reload) do not re-toast
            os.replace(_ctl_status_path(), _ctl_status_path() + ".done")
        except OSError:
            pass
    return jsonify(
        {
            "state": info.get("state"),
            "message": info.get("message"),
            "at": info.get("at"),
        }
    )


@bp.post("/restart")
@admin_required
def restart_server():
    if _ctl_running():
        return jsonify({"error": "already_running"}), 409
    if not _systemd_ok():
        return jsonify({"error": "no-systemd"}), 409
    try:
        proc = _spawn_ctl("restart")
    except OSError as exc:
        return jsonify({"error": "start_failed", "detail": str(exc)}), 500
    _write_ctl_status("restart", "running", pid=proc.pid)
    return jsonify({"started": True, "pid": proc.pid})


@bp.post("/uninstall")
@admin_required
def uninstall_server():
    if _ctl_running():
        return jsonify({"error": "already_running"}), 409
    if not _systemd_ok():
        return jsonify({"error": "no-systemd"}), 409
    try:
        proc = _spawn_ctl("uninstall")
    except OSError as exc:
        return jsonify({"error": "start_failed", "detail": str(exc)}), 500
    _write_ctl_status("uninstall", "running", pid=proc.pid)
    return jsonify({"started": True, "pid": proc.pid})


@bp.get("/server-status")
@admin_required
def server_status():
    """Everything the admin panel shows in the server status window."""
    data_dir = current_app.config["DATA_DIR"]
    try:
        db_size = os.path.getsize(current_app.config["DATABASE"])
    except OSError:
        db_size = 0
    try:
        disk_free = shutil.disk_usage(data_dir).free
    except OSError:
        disk_free = None
    host = port = None
    try:
        info = json.loads(
            (
                Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                / "install.json"
            ).read_text(encoding="utf-8")
        )
        host = info.get("host")
        port = info.get("port")
    except (OSError, ValueError):
        pass
    service = None
    if _systemd_ok():
        try:
            active = subprocess.run(
                ["systemctl", "is-active", SERVICE_NAME],
                capture_output=True,
                text=True,
                timeout=10,
            ).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            active = "unknown"
        service = {"name": SERVICE_NAME, "state": active or "unknown"}
    return jsonify(
        {
            "version": APP_VERSION,
            "schema": SCHEMA_VERSION,
            "uptime_seconds": int(time.monotonic() - START_MONOTONIC),
            "db_size_bytes": db_size,
            "python": platform.python_version(),
            "platform": f"{platform.system()} {platform.release()}",
            "install_dir": os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "data_dir": data_dir,
            "host": host,
            "port": port,
            "disk_free_bytes": disk_free,
            "service": service,
            "last_ctl": _read_ctl_status(),
        }
    )


@bp.get("/server-log")
@admin_required
def server_log():
    """Return the application log, falling back to server.log and journald."""
    try:
        count = int(request.args.get("lines", 300))
    except (TypeError, ValueError):
        count = 300
    count = max(20, min(count, 1000))
    lines: list[str] = []
    source = "none"
    log_errors: list[str] = []
    for filename in ("application.log", "server.log"):
        log_file = os.path.join(current_app.config["DATA_DIR"], filename)
        try:
            with open(log_file, "rb") as handle:
                handle.seek(0, os.SEEK_END)
                size = handle.tell()
                handle.seek(max(0, size - 512 * 1024))
                raw = handle.read().decode("utf-8", "replace")
            lines = raw.splitlines()[-count:]
            if lines:
                source = filename
                break
        except FileNotFoundError:
            continue
        except OSError as exc:
            log_errors.append(f"{filename}: {exc.strerror or exc.__class__.__name__}")
    if not lines and _systemd_ok():
        try:
            proc = subprocess.run(
                [
                    "journalctl",
                    "-u",
                    SERVICE_NAME,
                    "-n",
                    str(count),
                    "--no-pager",
                    "-o",
                    "cat",
                ],
                capture_output=True,
                text=True,
                timeout=15,
            )
            if proc.returncode == 0:
                lines = proc.stdout.splitlines()[-count:]
                if lines:
                    source = "journal"
            elif proc.stderr.strip():
                log_errors.append(f"journalctl: {proc.stderr.strip()[:300]}")
        except (OSError, subprocess.SubprocessError):
            log_errors.append("journalctl: command failed")
    response = {"lines": lines, "source": source}
    if not lines and log_errors:
        response["error"] = "; ".join(log_errors)
    return jsonify(response)
