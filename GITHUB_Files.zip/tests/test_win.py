# -*- coding: utf-8 -*-
"""v1.4.0 regression tests: Windows launcher commands of the installer
(installer/win.py): the Start-menu shortcut and the autostart entry must
both launch ``python app.py --host … --port …`` — the script is mandatory,
otherwise the user gets ``Unknown option: --host`` and no server."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from installer import win as w  # noqa: E402


def _capture_run(monkeypatch):
    calls = []

    def fake_run(cmd, timeout=1800, **kw):
        calls.append(cmd)
        return 0

    monkeypatch.setattr(w, "_run", fake_run)
    return calls


def _ps_string_value(ps: str, prop: str) -> str:
    """Extract the value assigned to a PowerShell string property, e.g.
    ``$lnk.Arguments = "…";``. The literal is JSON-escaped (backslashes
    doubled) and PowerShell treats backslashes literally, so json.loads
    restores the exact value the .lnk will receive."""
    m = re.search(rf"{re.escape(prop)} = \"([^\"]*)\"", ps)
    assert m, f"{prop} statement not found in: {ps}"
    return json.loads(f'"{m.group(1)}"')


def test_create_start_shortcut_arguments_include_app_py(monkeypatch, tmp_path):
    """Regression (1.11.2026): the Start-menu shortcut was created with
    Arguments='--host 0.0.0.0 --port 8765' and NO app.py, so it ran
    'python.exe --host …' → 'Unknown option: --host' and the server never
    started. Arguments must carry the absolute path to app.py."""
    calls = _capture_run(monkeypatch)
    install_dir = tmp_path / "Bookmarks"
    python = "C:\\Bookmarks\\.venv\\Scripts\\python.exe"
    w.create_start_shortcut(python, install_dir, "0.0.0.0", 8765)

    assert len(calls) == 1
    cmd = calls[0]
    assert cmd[0] == "powershell"
    ps = cmd[-1]

    assert _ps_string_value(ps, "$lnk.Arguments") == \
        f"{install_dir / 'app.py'} --host 0.0.0.0 --port 8765"
    assert _ps_string_value(ps, "$lnk.TargetPath") == python
    assert _ps_string_value(ps, "$lnk.WorkingDirectory") == str(install_dir)
    assert "Bookmarks.lnk" in ps


def test_create_start_shortcut_localhost_port(monkeypatch, tmp_path):
    calls = _capture_run(monkeypatch)
    install_dir = tmp_path / "B"
    w.create_start_shortcut("python", install_dir, "127.0.0.1", 9000)
    ps = calls[0][-1]
    assert _ps_string_value(ps, "$lnk.Arguments") == \
        f"{install_dir / 'app.py'} --host 127.0.0.1 --port 9000"


def test_enable_autostart_contains_app_py(monkeypatch, tmp_path):
    """The autostart entry already was correct — keep it that way: the
    registry value must contain the app.py path plus host/port flags."""
    calls = _capture_run(monkeypatch)
    install_dir = tmp_path / "Bookmarks"
    w.enable_autostart("C:\\Bookmarks\\.venv\\Scripts\\python.exe",
                       install_dir, "0.0.0.0", 8765)

    assert len(calls) == 1
    cmd = calls[0]
    assert cmd[0] == "reg"
    value = cmd[cmd.index("/d") + 1]
    assert f'"{install_dir / "app.py"}"' in value
    assert "--host 0.0.0.0" in value
    assert "--port 8765" in value
