# -*- coding: utf-8 -*-
"""v1.4.0 regression tests: the self-contained installer bootstrapper
(installer_bootstrap.py → bookmarks_install_v140.exe)."""

from __future__ import annotations

import sys
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import installer_bootstrap as b  # noqa: E402


# ---------------------------------------------------------------------------
# constants
# ---------------------------------------------------------------------------


def test_constants():
    assert b.REPO == "evgeniy7f2/Bookmarks"
    assert b.ASSET_NAME == "GITHUB_Files.zip"
    assert b.BOOTSTRAP_VERSION == "1.4.0"
    assert b.BRANCH_ZIP == (
        "https://github.com/evgeniy7f2/Bookmarks/archive/refs/heads/main.zip"
    )
    assert b.API.endswith("/repos/evgeniy7f2/Bookmarks")


# ---------------------------------------------------------------------------
# extract_payload (flat release-asset zip and wrapped GitHub zipball)
# ---------------------------------------------------------------------------


def _make_zip(path: Path, wrapped: bool, with_installer: bool = True) -> None:
    prefix = Path("Bookmarks-main") if wrapped else Path(".")
    with zipfile.ZipFile(path, "w") as z:
        if with_installer:
            z.writestr(str(prefix / "installer" / "__init__.py"), "")
            z.writestr(str(prefix / "installer" / "core.py"), "X = 1\n")
        z.writestr(str(prefix / "app.py"), "print('app')\n")
        z.writestr(str(prefix / "bookmarks" / "__init__.py"), "")


def test_extract_payload_flat(monkeypatch, tmp_path):
    monkeypatch.setattr(b, "PAYLOAD_DIR", tmp_path / "payload")
    z = tmp_path / "flat.zip"
    _make_zip(z, wrapped=False)
    got = b.extract_payload(z)
    assert got == tmp_path / "payload"
    assert (got / "installer" / "core.py").is_file()
    assert (got / "app.py").is_file()


def test_extract_payload_wrapped_zipball(monkeypatch, tmp_path):
    monkeypatch.setattr(b, "PAYLOAD_DIR", tmp_path / "payload")
    z = tmp_path / "wrapped.zip"
    _make_zip(z, wrapped=True)
    got = b.extract_payload(z)
    assert got == tmp_path / "payload"
    # the wrapper folder must not remain in the payload root
    assert (got / "Bookmarks-main").is_dir() is False
    assert (got / "installer" / "__init__.py").is_file()


def test_extract_payload_without_installer(monkeypatch, tmp_path):
    monkeypatch.setattr(b, "PAYLOAD_DIR", tmp_path / "payload")
    z = tmp_path / "plain.zip"
    _make_zip(z, wrapped=False, with_installer=False)
    assert b.extract_payload(z) is None


def test_extract_payload_replaces_previous(monkeypatch, tmp_path):
    monkeypatch.setattr(b, "PAYLOAD_DIR", tmp_path / "payload")
    z1, z2 = tmp_path / "a.zip", tmp_path / "b.zip"
    _make_zip(z1, wrapped=False)
    _make_zip(z2, wrapped=False)
    b.extract_payload(z1)
    got = b.extract_payload(z2)
    assert got == tmp_path / "payload"
    assert (got / "installer" / "__init__.py").is_file()


# ---------------------------------------------------------------------------
# embedded payload / flags
# ---------------------------------------------------------------------------


def test_embedded_payload_dir_not_frozen(monkeypatch):
    monkeypatch.setattr(b, "FROZEN", False)
    assert b.embedded_payload_dir() is None


def test_flag_value():
    assert b._flag_value(["--offline", "D:\\x"], "--offline") == "D:\\x"
    assert b._flag_value(["--offline"], "--offline") is None  # no value
    assert b._flag_value([], "--offline") is None
    assert b._flag_value(["--download", "u"], "--other") is None


# ---------------------------------------------------------------------------
# GitHub source resolution
# ---------------------------------------------------------------------------


def test_resolve_download_url_prefers_release_asset(monkeypatch):
    info = {
        "tag_name": "v1.4.0",
        "assets": [
            {"name": "other.zip", "browser_download_url": "https://x/other.zip"},
            {"name": "GITHUB_Files.zip", "browser_download_url": "https://x/files.zip"},
        ],
    }
    monkeypatch.setattr(b, "http_json", lambda url, timeout=20: info)
    url, label = b.resolve_download_url()
    assert url == "https://x/files.zip"
    assert "v1.4.0" in label


def test_candidate_urls_api_failure_falls_back_to_branch(monkeypatch):
    def boom(url, timeout=20):
        raise OSError("no network")

    monkeypatch.setattr(b, "http_json", boom)
    urls = [u for u, _ in b.candidate_urls()]
    assert b.RAW_FILE in urls
    assert urls[-1] == b.BRANCH_ZIP


def test_resolve_download_url_uses_renamed_zip_asset(monkeypatch):
    """Regression: a user may attach the payload under any *.zip name (not the
    exact ASSET_NAME); the bootstrap must still find it."""
    info = {
        "tag_name": "v1.5.0",
        "assets": [
            {"name": "Bookmarks_v1.5.0.zip",
             "browser_download_url": "https://x/renamed.zip"},
        ],
    }
    monkeypatch.setattr(b, "http_json", lambda url, timeout=20: info)
    url, label = b.resolve_download_url()
    assert url == "https://x/renamed.zip"
    assert "v1.5.0" in label


def test_candidate_urls_body_link_after_raw_file(monkeypatch):
    """A *.zip URL pasted into the release body is used, but the raw
    GITHUB_Files.zip in the main branch is tried first (it is smaller and,
    if present, always the payload)."""
    info = {
        "tag_name": "v1.4.0",
        "assets": [],
        "body": ("Download [GITHUB_Files.zip]"
                 "(https://github.com/user-attachments/files/1/GITHUB_Files.zip) "
                 "and install."),
    }
    monkeypatch.setattr(b, "http_json", lambda url, timeout=20: info)
    urls = [u for u, _ in b.candidate_urls()]
    assert urls[0] == b.RAW_FILE
    assert "https://github.com/user-attachments/files/1/GITHUB_Files.zip" in urls
    assert urls[-1] == b.BRANCH_ZIP


def test_candidate_urls_installer_named_body_link_late(monkeypatch):
    """A body link whose name looks like the exe wrapper (…install….zip) is a
    zip of the installer exe, not the payload — it must be tried after the
    other sources, before the branch zipball."""
    info = {
        "tag_name": "v1.4.0",
        "assets": [],
        "body": ("[exe](https://a/bookmarks_install_v140.zip) "
                 "[payload](https://a/payload.zip)"),
    }
    monkeypatch.setattr(b, "http_json", lambda url, timeout=20: info)
    urls = [u for u, _ in b.candidate_urls()]
    assert urls.index("https://a/payload.zip") < urls.index(
        "https://a/bookmarks_install_v140.zip")
    assert urls[-1] == b.BRANCH_ZIP


def test_candidate_urls_excludes_duplicate_urls(monkeypatch):
    info = {
        "tag_name": "v1.4.0",
        "assets": [{"name": "GITHUB_Files.zip",
                    "browser_download_url": b.RAW_FILE}],
        "body": f"[same]({b.RAW_FILE})",
    }
    monkeypatch.setattr(b, "http_json", lambda url, timeout=20: info)
    urls = [u for u, _ in b.candidate_urls()]
    assert urls.count(b.RAW_FILE) == 1


def test_resolve_download_url_asset_beats_body_link(monkeypatch):
    """An attached asset must win over a body link (assets are more reliable)."""
    info = {
        "tag_name": "v1.4.0",
        "assets": [
            {"name": "GITHUB_Files.zip",
             "browser_download_url": "https://x/asset.zip"},
        ],
        "body": "[old](https://github.com/user-attachments/files/1/old.zip)",
    }
    monkeypatch.setattr(b, "http_json", lambda url, timeout=20: info)
    url, label = b.resolve_download_url()
    assert url == "https://x/asset.zip"
    assert "asset" in label


# ---------------------------------------------------------------------------
# zip_has_installer quick check
# ---------------------------------------------------------------------------


def test_zip_has_installer_flat(tmp_path):
    z = tmp_path / "flat.zip"
    _make_zip(z, wrapped=False)
    assert b.zip_has_installer(z) is True


def test_zip_has_installer_wrapped_zipball(tmp_path):
    z = tmp_path / "wrapped.zip"
    _make_zip(z, wrapped=True)
    assert b.zip_has_installer(z) is True


def test_zip_has_installer_absent(tmp_path):
    z = tmp_path / "plain.zip"
    _make_zip(z, wrapped=False, with_installer=False)
    assert b.zip_has_installer(z) is False


def test_zip_has_installer_bad_zip(tmp_path):
    z = tmp_path / "bad.zip"
    z.write_bytes(b"not a zip file at all")
    assert b.zip_has_installer(z) is False


# ---------------------------------------------------------------------------
# download() with a fake HTTP response
# ---------------------------------------------------------------------------


class _FakeResp:
    def __init__(self, data: bytes):
        self._buf = data
        self.headers = {"Content-Length": str(len(data))}

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def read(self, n=-1):
        chunk = self._buf[:n]
        self._buf = self._buf[n:]
        return chunk


def test_download_streams_and_reports_progress(monkeypatch, tmp_path):
    data = b"0123456789" * 3000  # 30 KB, several chunks
    monkeypatch.setattr(
        b.urllib.request, "urlopen", lambda req, timeout=0: _FakeResp(data)
    )
    got_calls = []
    dest = tmp_path / "sub" / "out.zip"
    b.download("https://example/x.zip", dest, lambda g, t: got_calls.append((g, t)))
    assert dest.read_bytes() == data
    assert got_calls, "progress callback never called"
    assert got_calls[-1] == (len(data), len(data))


# ---------------------------------------------------------------------------
# multi-candidate download flow (the real GitHub situation of v1.4.0:
# no release assets, a wrong zip link in the body, the payload zip
# committed to the main branch)
# ---------------------------------------------------------------------------


def _fake_zip_serving(bad_data: bytes, good_data: bytes, monkeypatch):
    """Serve the 'bad' zip for URLs containing bad.zip, the good one for
    good.zip, and fail for anything else."""

    def fake_urlopen(req, timeout=0):
        url = req.full_url
        if "bad.zip" in url:
            return _FakeResp(bad_data)
        if "good.zip" in url:
            return _FakeResp(good_data)
        raise ConnectionError(f"unexpected url {url}")

    monkeypatch.setattr(b.urllib.request, "urlopen", fake_urlopen)


def test_download_payload_tries_next_source_when_installer_missing(
        monkeypatch, tmp_path):
    """A candidate without installer/ (e.g. a zip of the exe) must be
    skipped automatically and the next source tried."""
    bad = tmp_path / "bad.zip"
    _make_zip(bad, wrapped=False, with_installer=False)
    good = tmp_path / "good.zip"
    _make_zip(good, wrapped=False)
    _fake_zip_serving(bad.read_bytes(), good.read_bytes(), monkeypatch)
    monkeypatch.setattr(b, "http_json", lambda url, timeout=20: {
        "tag_name": "v9",
        "assets": [{"name": "bad.zip",
                    "browser_download_url": "https://x/bad.zip"}],
        "body": "[good](https://x/good.zip)",
    })
    monkeypatch.setattr(b, "PAYLOAD_DIR", tmp_path / "payload")
    monkeypatch.setattr(b, "ZIP_PATH", tmp_path / "payload.zip")
    payload, err = b.download_payload(None)
    assert err is None
    assert payload is not None
    assert (payload / "installer").is_dir()


def test_download_payload_all_sources_fail(monkeypatch, tmp_path):
    bad = tmp_path / "bad.zip"
    _make_zip(bad, wrapped=False, with_installer=False)
    data = bad.read_bytes()
    monkeypatch.setattr(b.urllib.request, "urlopen",
                        lambda req, timeout=0: _FakeResp(data))
    monkeypatch.setattr(b, "http_json",
                        lambda url, timeout=20: {"tag_name": "v9",
                                                  "assets": [], "body": ""})
    monkeypatch.setattr(b, "PAYLOAD_DIR", tmp_path / "payload")
    monkeypatch.setattr(b, "ZIP_PATH", tmp_path / "payload.zip")
    payload, err = b.download_payload(None)
    assert payload is None
    assert err and "installer/" in err
